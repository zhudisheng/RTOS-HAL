FreeRTOS 2020107.00 adds a new SNTPv4 client library, [FreeRTOS/coreSNTP](https://github.com/FreeRTOS/coreSNTP),
and an [accompanying demo](..\..\..\coreSNTP_Windows_Simulator) to showcase the setup of an SNTP client and system 
wall-clock time using the library. Refer to 
The protocols implemented in this directory are intended to be demo quality
examples only.  They are not intended for inclusion in production devices.
