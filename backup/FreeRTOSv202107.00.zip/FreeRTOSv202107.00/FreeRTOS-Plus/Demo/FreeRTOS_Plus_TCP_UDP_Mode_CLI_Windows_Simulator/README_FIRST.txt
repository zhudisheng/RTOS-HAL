This demo is documented on the following web page:
http://www.FreeRTOS.org/FreeRTOS-Plus/FreeRTOS_Plus_UDP/Embedded_Ethernet_Examples/RTOS_UDP_CLI_Windows_Simulator.shtml

The FreeRTOS+UDP API is documented on the following web page:
http://www.FreeRTOS.org/FreeRTOS-Plus/FreeRTOS_Plus_UDP/FreeRTOS_UDP_API_Functions.shtml

Other information, including a FreeRTOS+UDP primer, a description of the 
directory structure, and a glossary of networking terminology, can be found in 
the FreeRTOS+UDP portal:
http://www.FreeRTOS.org/udp

